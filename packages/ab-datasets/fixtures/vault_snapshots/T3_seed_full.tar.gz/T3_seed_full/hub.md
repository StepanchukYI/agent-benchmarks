# Hub

Project: `<example-project>`
Owner: `<operator>`
Status: active
Updated: 2026-05-21

## Identity (L0)

Code-graph benchmark harness. Multi-runner / multi-model. T0/T1/T2/T3
config tiers. Inspect-AI bridge for orchestrated evals.

## Active decisions

See `decisions.md` (most recent first).

## Active lessons

See `lessons.md` (most recent first).

## Open items

- Wire factory into ab CLI (`--runner anthropic-compat --model glm-4.6`).
- Populate L1 memory tasks.
- Stand up real GitHub OAuth App for the live deploy.

Notes: anonymized seed for T3 fixture; do not reference real systems.
