# Decisions

---
id: dec-001
date: 2026-05-15
importance: 4
sub_type: architecture
valid_until: null
---

Adopt the registry-map approach for `SCORER_PILLAR_MAP` instead of a
`pillar` field on `ScorerVerdict`. Keeps the schema stable; new
scorers register the pillar in one place. Trade-off: a misnamed scorer
defaults to `correctness` rather than failing loudly. Acceptable for
v1.

---
id: dec-002
date: 2026-05-18
importance: 3
sub_type: tooling
valid_until: 2026-12-31
---

Use Track A (runner / scorer / server infra) + Track B (task content)
split for the L0 closure. Single-thread coordination via merge
commits. Re-evaluate when L2 lands and the touch surfaces overlap.

<!-- append new entries above this line -->
