# Lessons

---
title: Sandbox prompt prevents claude-code from auto-loading CLAUDE.md
date: 2026-05-21
---

Real claude-code runs in a workdir inside the repo silently picked up
the repo's CLAUDE.md, skills, and MCPs. Agent then "implemented" the
benchmark task as if it were a feature request on the host project.
Fix: append a sandbox system prompt via `--append-system-prompt` plus
move the workdir outside the host repo's CLAUDE.md discovery root.

---
title: Weighted scoring requires aligned write + read paths
date: 2026-05-21
---

`build_scores_payload` computed weighted totals; the rescoring engine
used unweighted means. On any task with non-uniform `weights` the
verified trust tier became permanently unreachable even with identical
agent behavior. Extracted `compute_total_score()` as the single source
of truth; both paths now call it. Lesson: any time two code paths
compute the same quantity, factor + share.

<!-- append new entries above this line -->
